# Cosmic Observer — Native Android Studio Project (APK)

This directory contains the native Kotlin + Gradle Android application that embeds the offline-bundled **Cosmic Observer 3D WebGL2 Engine** as both:

1. **Android System Live Wallpaper** (`CosmicWallpaperService` using hardware-accelerated `VirtualDisplay` + `Presentation` + `WebViewAssetLoader`).
2. **Android Home Screen Launcher** (`LauncherActivity` declaring `android.intent.category.HOME` + `PackageManager` installed-app drawer & system telemetry bridge).

## Build & Sideload Instructions

1. From the workspace root, build and copy the production Vite Three.js bundle into `android/app/src/main/assets/`:

   ```bash
   npm run android:sync
   ```

2. Open `/android` in **Android Studio (Ladybug / 2024.2+)** with Android SDK 35 & JDK 17.
3. Let Gradle sync, then run on your Android device via USB Debugging or build an APK (`Build > Build Bundle(s) / APK(s) > Build APK(s)`).
4. Inside **Cosmic Observer** -> open **Customization Studio -> Android** tab -> tap **Set Live Wallpaper** or **Set Default Home**.
