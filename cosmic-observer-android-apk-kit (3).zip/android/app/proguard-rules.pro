-keepattributes *Annotation*
-keepclassmembers class com.cosmicobserver.wallpaper.bridge.CosmicAndroidBridge {
    @android.webkit.JavascriptInterface <methods>;
}
