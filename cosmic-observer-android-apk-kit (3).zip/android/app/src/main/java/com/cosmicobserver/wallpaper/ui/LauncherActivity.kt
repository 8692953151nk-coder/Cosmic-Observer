package com.cosmicobserver.wallpaper.ui

import android.annotation.SuppressLint
import android.content.res.Configuration
import android.graphics.Color
import android.os.Bundle
import android.view.View
import android.view.ViewGroup
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.webkit.WebViewAssetLoader
import com.cosmicobserver.wallpaper.bridge.CosmicAndroidBridge
import com.cosmicobserver.wallpaper.sensor.CosmicGyroController
import java.util.Locale

/**
 * Minimal Companion Preview Activity.
 * Displays the live interactive 3D character preview with a single "Set as Wallpaper"
 * button that opens Android's native Live Wallpaper preview and confirmation screen.
 * Automatically tracks system Dark / Light mode changes in real time.
 */
class LauncherActivity : AppCompatActivity() {

    private lateinit var webView: WebView
    private lateinit var androidBridge: CosmicAndroidBridge
    private lateinit var gyroController: CosmicGyroController
    private var engineReady = false

    companion object {
        private val LIGHT_BACKGROUND_COLOR = Color.parseColor("#F4F6F9")
    }

    private fun isSystemDarkMode(config: Configuration = resources.configuration): Boolean {
        return (config.uiMode and Configuration.UI_MODE_NIGHT_MASK) == Configuration.UI_MODE_NIGHT_YES
    }

    private fun applySystemBarsTheme(isDark: Boolean) {
        WindowInsetsControllerCompat(window, window.decorView).apply {
            isAppearanceLightStatusBars = !isDark
            isAppearanceLightNavigationBars = !isDark
        }
    }

    private fun syncThemeToWebView(isDark: Boolean) {
        if (!::webView.isInitialized) return
        webView.setBackgroundColor(if (isDark) Color.BLACK else LIGHT_BACKGROUND_COLOR)
        if (engineReady) {
            webView.evaluateJavascript(
                "window.__COSMIC_ANDROID_THEME__?.($isDark);",
                null
            )
        }
    }

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val initialDark = isSystemDarkMode()
        WindowCompat.setDecorFitsSystemWindows(window, false)
        window.statusBarColor = Color.TRANSPARENT
        window.navigationBarColor = Color.TRANSPARENT
        applySystemBarsTheme(initialDark)

        androidBridge = CosmicAndroidBridge(
            context = this,
            onEngineReady = {
                engineReady = true
                syncThemeToWebView(isSystemDarkMode())
                webView.evaluateJavascript(
                    "window.__COSMIC_ANDROID_LIFECYCLE__?.(true, false);",
                    null
                )
            }
        )

        gyroController = CosmicGyroController(this) { nx, ny ->
            if (!engineReady) return@CosmicGyroController
            runOnUiThread {
                val js = String.format(
                    Locale.US,
                    "window.__COSMIC_ANDROID_GYRO__?.(%.4f, %.4f);",
                    nx,
                    ny
                )
                webView.evaluateJavascript(js, null)
            }
        }

        val assetLoader = WebViewAssetLoader.Builder()
            .setDomain("appassets.androidplatform.net")
            .addPathHandler("/", WebViewAssetLoader.AssetsPathHandler(this))
            .build()

        webView = WebView(this).apply {
            setBackgroundColor(if (initialDark) Color.BLACK else LIGHT_BACKGROUND_COLOR)
            setLayerType(View.LAYER_TYPE_HARDWARE, null)
            overScrollMode = View.OVER_SCROLL_NEVER
            isHorizontalScrollBarEnabled = false
            isVerticalScrollBarEnabled = false

            settings.apply {
                javaScriptEnabled = true
                domStorageEnabled = true
                allowFileAccess = false
                allowContentAccess = false
                mixedContentMode = WebSettings.MIXED_CONTENT_NEVER_ALLOW
                useWideViewPort = true
                loadWithOverviewMode = true
            }

            addJavascriptInterface(androidBridge, "CosmicAndroidBridge")

            webViewClient = object : WebViewClient() {
                override fun shouldInterceptRequest(
                    view: WebView,
                    request: WebResourceRequest
                ): WebResourceResponse? {
                    return assetLoader.shouldInterceptRequest(request.url)
                }
            }

            loadUrl("https://appassets.androidplatform.net/index.html?androidCompanion=1")
        }

        setContentView(
            webView,
            ViewGroup.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT
            )
        )
    }

    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)
        val isDark = isSystemDarkMode(newConfig)
        applySystemBarsTheme(isDark)
        syncThemeToWebView(isDark)
    }

    override fun onResume() {
        super.onResume()
        val isDark = isSystemDarkMode()
        applySystemBarsTheme(isDark)
        webView.onResume()
        gyroController.start()
        if (engineReady) {
            syncThemeToWebView(isDark)
            webView.evaluateJavascript(
                "window.__COSMIC_ANDROID_LIFECYCLE__?.(true, false);",
                null
            )
        }
    }

    override fun onPause() {
        gyroController.stop()
        if (engineReady) {
            webView.evaluateJavascript(
                "window.__COSMIC_ANDROID_LIFECYCLE__?.(false, false);",
                null
            )
        }
        webView.onPause()
        super.onPause()
    }

    override fun onDestroy() {
        gyroController.stop()
        androidBridge.release()
        webView.stopLoading()
        webView.destroy()
        super.onDestroy()
    }
}
