package com.cosmicobserver.wallpaper.bridge

import android.app.WallpaperManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.res.Configuration
import android.os.Handler
import android.os.Looper
import android.webkit.JavascriptInterface
import com.cosmicobserver.wallpaper.service.CosmicWallpaperService

/**
 * Minimal JavaScript-to-Android bridge for the Cosmic Observer Live Wallpaper.
 * Handles engine readiness signaling, system Dark/Light mode queries,
 * and launching Android's native Live Wallpaper picker.
 */
class CosmicAndroidBridge(
    private val context: Context,
    private val onEngineReady: (() -> Unit)? = null
) {
    private val mainHandler = Handler(Looper.getMainLooper())

    @JavascriptInterface
    fun isSystemDarkMode(): Boolean {
        val nightModeFlags =
            context.resources.configuration.uiMode and Configuration.UI_MODE_NIGHT_MASK
        return nightModeFlags == Configuration.UI_MODE_NIGHT_YES
    }

    @JavascriptInterface
    fun openLiveWallpaperPicker(): Boolean {
        val component = ComponentName(context, CosmicWallpaperService::class.java)
        val changeIntent = Intent(WallpaperManager.ACTION_CHANGE_LIVE_WALLPAPER).apply {
            putExtra(WallpaperManager.EXTRA_LIVE_WALLPAPER_COMPONENT, component)
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        return try {
            context.startActivity(changeIntent)
            true
        } catch (_: Throwable) {
            try {
                val chooser = Intent(WallpaperManager.ACTION_LIVE_WALLPAPER_CHOOSER).apply {
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                context.startActivity(chooser)
                true
            } catch (_: Throwable) {
                false
            }
        }
    }

    @JavascriptInterface
    fun notifyEngineReady() {
        onEngineReady?.let { callback ->
            mainHandler.post(callback)
        }
    }

    fun release() {
        mainHandler.removeCallbacksAndMessages(null)
    }
}
