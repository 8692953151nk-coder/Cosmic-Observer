package com.cosmicobserver.wallpaper.sensor

import android.content.Context
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.os.SystemClock
import kotlin.math.abs
import kotlin.math.atan2
import kotlin.math.sqrt

/**
 * Gimbal-lock-free, battery-friendly native Android gyroscope controller.
 *
 * Uses quaternion relative rotation on TYPE_GAME_ROTATION_VECTOR (preferred) or
 * TYPE_ROTATION_VECTOR so tilting/panning works smoothly at EVERY holding posture
 * (flat on table, 45-degree angle, or upright portrait at 90 degrees).
 * Automatically falls back to TYPE_GYROSCOPE (angular rate) or TYPE_ACCELEROMETER
 * (gravity vector delta) on devices lacking fused rotation vector sensors.
 */
class CosmicGyroController(
    context: Context,
    private val onTiltChanged: (nx: Float, ny: Float) -> Unit
) : SensorEventListener {

    private val sensorManager: SensorManager? =
        context.getSystemService(Context.SENSOR_SERVICE) as? SensorManager

    private val activeSensor: Sensor? =
        sensorManager?.getDefaultSensor(Sensor.TYPE_GAME_ROTATION_VECTOR)
            ?: sensorManager?.getDefaultSensor(Sensor.TYPE_ROTATION_VECTOR)
            ?: sensorManager?.getDefaultSensor(Sensor.TYPE_GYROSCOPE)
            ?: sensorManager?.getDefaultSensor(Sensor.TYPE_ACCELEROMETER)

    private var isRegistered = false
    private var hasBaseline = false

    // Baseline and previous unit quaternion [x, y, z, w] for rotation vector sensors
    private val baseQuat = FloatArray(4)
    private val lastQuat = FloatArray(4)
    private val currQuat = FloatArray(4)

    // Fallback state for raw gyroscope integration & accelerometer gravity delta
    private var gyroIntX = 0f
    private var gyroIntY = 0f
    private var lastGyroTimestampNs = 0L
    private val baseGravity = FloatArray(3)
    private val lastGravity = FloatArray(3)

    private var smoothedNx = 0f
    private var smoothedNy = 0f
    private var lastMotionTimeMs = 0L
    private var lastEmitTimeMs = 0L

    fun isAvailable(): Boolean = activeSensor != null

    fun start() {
        val manager = sensorManager ?: return
        val sensor = activeSensor ?: return
        if (isRegistered) return

        hasBaseline = false
        gyroIntX = 0f
        gyroIntY = 0f
        lastGyroTimestampNs = 0L
        smoothedNx = 0f
        smoothedNy = 0f
        lastMotionTimeMs = SystemClock.elapsedRealtime()
        lastEmitTimeMs = 0L

        isRegistered = manager.registerListener(
            this,
            sensor,
            SensorManager.SENSOR_DELAY_GAME
        )
    }

    fun stop() {
        if (!isRegistered) return
        sensorManager?.unregisterListener(this)
        isRegistered = false
        hasBaseline = false
        smoothedNx = 0f
        smoothedNy = 0f
    }

    override fun onSensorChanged(event: SensorEvent) {
        val nowMs = SystemClock.elapsedRealtime()

        when (event.sensor.type) {
            Sensor.TYPE_GAME_ROTATION_VECTOR,
            Sensor.TYPE_ROTATION_VECTOR -> {
                if (nowMs - lastEmitTimeMs < 24L) return
                handleRotationVector(event.values, nowMs)
            }
            Sensor.TYPE_GYROSCOPE -> {
                handleRawGyroscope(event.values, event.timestamp, nowMs)
            }
            Sensor.TYPE_ACCELEROMETER -> {
                if (nowMs - lastEmitTimeMs < 24L) return
                handleAccelerometer(event.values, nowMs)
            }
        }
    }

    private fun handleRotationVector(values: FloatArray, nowMs: Long) {
        if (values.size < 3) return
        val qx = values[0]
        val qy = values[1]
        val qz = values[2]
        val qw = if (values.size >= 4) {
            values[3]
        } else {
            sqrt((1f - qx * qx - qy * qy - qz * qz).coerceAtLeast(0f))
        }
        val norm = sqrt(qx * qx + qy * qy + qz * qz + qw * qw).coerceAtLeast(1e-5f)
        currQuat[0] = qx / norm
        currQuat[1] = qy / norm
        currQuat[2] = qz / norm
        currQuat[3] = qw / norm

        if (!hasBaseline) {
            currQuat.copyInto(baseQuat)
            currQuat.copyInto(lastQuat)
            lastMotionTimeMs = nowMs
            hasBaseline = true
            return
        }

        // Measure angular movement since previous sample
        val dotPrev = abs(
            lastQuat[0] * currQuat[0] +
                lastQuat[1] * currQuat[1] +
                lastQuat[2] * currQuat[2] +
                lastQuat[3] * currQuat[3]
        ).coerceAtMost(1f)
        currQuat.copyInto(lastQuat)

        if (1f - dotPrev > 0.00003f) {
            lastMotionTimeMs = nowMs
        }

        // Gently return neutral baseline after extended stillness
        if (nowMs - lastMotionTimeMs > 1200L) {
            nlerpToward(baseQuat, currQuat, 0.025f)
        }

        // Compute relative rotation qDelta = conj(baseQuat) * currQuat in device local coordinates
        val bx = -baseQuat[0]
        val by = -baseQuat[1]
        val bz = -baseQuat[2]
        val bw = baseQuat[3]

        val cx = currQuat[0]
        val cy = currQuat[1]
        val cz = currQuat[2]
        val cw = currQuat[3]

        var dx = bw * cx + bx * cw + by * cz - bz * cy
        var dy = bw * cy - bx * cz + by * cw + bz * cx
        var dz = bw * cz + bx * cy - by * cx + bz * cw
        var dw = bw * cw - bx * cx - by * cy - bz * cz

        if (dw < 0f) {
            dx = -dx
            dy = -dy
            dz = -dz
            dw = -dw
        }

        val sinHalf = sqrt(dx * dx + dy * dy + dz * dz)
        val scale = if (sinHalf > 1e-5f) (2f * atan2(sinHalf, dw)) / sinHalf else 2f

        val rotX = dx * scale
        val rotY = dy * scale
        val rotZ = dz * scale

        val rawHoriz = rotY - rotZ * 0.55f
        val rawVert = -rotX

        val cleanHoriz = if (abs(rawHoriz) < 0.008f) 0f else rawHoriz
        val cleanVert = if (abs(rawVert) < 0.008f) 0f else rawVert

        val targetNx = (cleanHoriz / 0.42f).coerceIn(-1f, 1f)
        val targetNy = (cleanVert / 0.42f).coerceIn(-1f, 1f)

        emitSmoothed(targetNx, targetNy, nowMs)
    }

    private fun handleRawGyroscope(values: FloatArray, timestampNs: Long, nowMs: Long) {
        if (values.size < 3) return
        if (lastGyroTimestampNs == 0L) {
            lastGyroTimestampNs = timestampNs
            return
        }
        val dt = ((timestampNs - lastGyroTimestampNs) / 1_000_000_000f).coerceIn(0.001f, 0.08f)
        lastGyroTimestampNs = timestampNs

        val wx = values[0] // pitch rad/s
        val wy = values[1] // yaw/turn rad/s
        val wz = values[2] // roll rad/s

        val horizRate = wy - wz * 0.5f
        val vertRate = -wx

        if (abs(horizRate) > 0.04f || abs(vertRate) > 0.04f) {
            lastMotionTimeMs = nowMs
            gyroIntX = (gyroIntX + horizRate * dt * 2.1f).coerceIn(-1f, 1f)
            gyroIntY = (gyroIntY + vertRate * dt * 2.1f).coerceIn(-1f, 1f)
        } else if (nowMs - lastMotionTimeMs > 1000L) {
            gyroIntX *= 0.96f
            gyroIntY *= 0.96f
        }

        if (nowMs - lastEmitTimeMs < 24L) return
        emitSmoothed(gyroIntX, gyroIntY, nowMs)
    }

    private fun handleAccelerometer(values: FloatArray, nowMs: Long) {
        if (values.size < 3) return
        val norm = sqrt(
            values[0] * values[0] + values[1] * values[1] + values[2] * values[2]
        ).coerceAtLeast(0.001f)
        val gx = values[0] / norm
        val gy = values[1] / norm
        val gz = values[2] / norm

        if (!hasBaseline) {
            baseGravity[0] = gx
            baseGravity[1] = gy
            baseGravity[2] = gz
            lastGravity[0] = gx
            lastGravity[1] = gy
            lastGravity[2] = gz
            lastMotionTimeMs = nowMs
            hasBaseline = true
            return
        }

        val moved = abs(gx - lastGravity[0]) + abs(gy - lastGravity[1]) + abs(gz - lastGravity[2])
        lastGravity[0] = gx
        lastGravity[1] = gy
        lastGravity[2] = gz
        if (moved > 0.015f) {
            lastMotionTimeMs = nowMs
        }

        if (nowMs - lastMotionTimeMs > 1200L) {
            baseGravity[0] += (gx - baseGravity[0]) * 0.025f
            baseGravity[1] += (gy - baseGravity[1]) * 0.025f
            baseGravity[2] += (gz - baseGravity[2]) * 0.025f
        }

        val targetNx = (-(gx - baseGravity[0]) / 0.42f).coerceIn(-1f, 1f)
        val targetNy = ((gz - baseGravity[2]) / 0.42f).coerceIn(-1f, 1f)

        emitSmoothed(targetNx, targetNy, nowMs)
    }

    private fun emitSmoothed(targetNx: Float, targetNy: Float, nowMs: Long) {
        smoothedNx += (targetNx - smoothedNx) * 0.30f
        smoothedNy += (targetNy - smoothedNy) * 0.30f

        if (abs(smoothedNx) < 0.003f) smoothedNx = 0f
        if (abs(smoothedNy) < 0.003f) smoothedNy = 0f

        lastEmitTimeMs = nowMs
        onTiltChanged(smoothedNx, smoothedNy)
    }

    private fun nlerpToward(base: FloatArray, target: FloatArray, alpha: Float) {
        var dot = base[0] * target[0] + base[1] * target[1] + base[2] * target[2] + base[3] * target[3]
        val sign = if (dot < 0f) -1f else 1f
        base[0] += (target[0] * sign - base[0]) * alpha
        base[1] += (target[1] * sign - base[1]) * alpha
        base[2] += (target[2] * sign - base[2]) * alpha
        base[3] += (target[3] * sign - base[3]) * alpha
        val norm = sqrt(base[0] * base[0] + base[1] * base[1] + base[2] * base[2] + base[3] * base[3])
            .coerceAtLeast(1e-5f)
        base[0] /= norm
        base[1] /= norm
        base[2] /= norm
        base[3] /= norm
    }

    override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) {
        // No action required
    }
}
