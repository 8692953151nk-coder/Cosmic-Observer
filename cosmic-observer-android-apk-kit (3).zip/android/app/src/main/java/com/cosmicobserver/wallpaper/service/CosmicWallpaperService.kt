package com.cosmicobserver.wallpaper.service

import android.annotation.SuppressLint
import android.app.Presentation
import android.app.WallpaperColors
import android.content.Context
import android.content.res.Configuration
import android.graphics.Color
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.service.wallpaper.WallpaperService
import android.view.MotionEvent
import android.view.SurfaceHolder
import android.view.View
import android.view.ViewGroup
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.annotation.RequiresApi
import androidx.webkit.WebViewAssetLoader
import com.cosmicobserver.wallpaper.bridge.CosmicAndroidBridge
import com.cosmicobserver.wallpaper.sensor.CosmicGyroController
import java.util.Locale
import java.util.concurrent.CopyOnWriteArraySet

class CosmicWallpaperService : WallpaperService() {

    private val activeEngines = CopyOnWriteArraySet<CosmicEngine>()

    companion object {
        private val LIGHT_BACKGROUND_COLOR = Color.parseColor("#F4F6F9")
        private val LIGHT_ACCENT_COLOR = Color.parseColor("#0F172A")
        private val DARK_SECONDARY_COLOR = Color.parseColor("#1E293B")
    }

    private fun isSystemDarkMode(config: Configuration = resources.configuration): Boolean {
        return (config.uiMode and Configuration.UI_MODE_NIGHT_MASK) == Configuration.UI_MODE_NIGHT_YES
    }

    override fun onCreateEngine(): Engine = CosmicEngine()

    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)
        val isDark = isSystemDarkMode(newConfig)
        activeEngines.forEach { engine ->
            engine.onSystemThemeChanged(isDark)
        }
    }

    inner class CosmicEngine : Engine() {
        private val mainHandler = Handler(Looper.getMainLooper())
        private var virtualDisplay: VirtualDisplay? = null
        private var presentation: Presentation? = null
        private var webView: WebView? = null
        private var bridge: CosmicAndroidBridge? = null
        private var gyroController: CosmicGyroController? = null
        private var isEngineReady = false
        private var currentVisible = false
        private var currentIsDarkMode = isSystemDarkMode()

        override fun onCreate(surfaceHolder: SurfaceHolder?) {
            super.onCreate(surfaceHolder)
            activeEngines.add(this)
            currentIsDarkMode = isSystemDarkMode()
            setTouchEventsEnabled(true)
            setOffsetNotificationsEnabled(true)

            gyroController = CosmicGyroController(this@CosmicWallpaperService) { nx, ny ->
                if (!isEngineReady || !currentVisible) return@CosmicGyroController
                mainHandler.post {
                    val js = String.format(
                        Locale.US,
                        "window.__COSMIC_ANDROID_GYRO__?.(%.4f, %.4f);",
                        nx,
                        ny
                    )
                    webView?.evaluateJavascript(js, null)
                }
            }
        }

        fun onSystemThemeChanged(isDark: Boolean) {
            currentIsDarkMode = isDark
            mainHandler.post {
                webView?.setBackgroundColor(if (isDark) Color.BLACK else LIGHT_BACKGROUND_COLOR)
                syncThemeToWeb(isDark)
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O_MR1) {
                    notifyColorsChanged()
                }
            }
        }

        @RequiresApi(Build.VERSION_CODES.O_MR1)
        override fun onComputeColors(): WallpaperColors {
            val isDark = currentIsDarkMode
            val primary = Color.valueOf(if (isDark) Color.BLACK else LIGHT_BACKGROUND_COLOR)
            val secondary = Color.valueOf(if (isDark) DARK_SECONDARY_COLOR else LIGHT_ACCENT_COLOR)
            val tertiary = Color.valueOf(if (isDark) Color.WHITE else Color.DKGRAY)

            return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                val hints = if (isDark) {
                    WallpaperColors.HINT_SUPPORTS_DARK_THEME
                } else {
                    WallpaperColors.HINT_SUPPORTS_DARK_TEXT
                }
                WallpaperColors(primary, secondary, tertiary, hints)
            } else {
                WallpaperColors(primary, secondary, tertiary)
            }
        }

        override fun onSurfaceChanged(
            holder: SurfaceHolder,
            format: Int,
            width: Int,
            height: Int
        ) {
            super.onSurfaceChanged(holder, format, width, height)
            if (width <= 0 || height <= 0) return

            mainHandler.post {
                if (virtualDisplay == null) {
                    setupVirtualDisplayPresentation(holder, width, height)
                } else {
                    val densityDpi = resources.displayMetrics.densityDpi
                    virtualDisplay?.resize(width, height, densityDpi)
                }
            }
        }

        @SuppressLint("SetJavaScriptEnabled")
        private fun setupVirtualDisplayPresentation(
            holder: SurfaceHolder,
            width: Int,
            height: Int
        ) {
            cleanupPresentation()

            val surface = holder.surface ?: return
            if (!surface.isValid) return

            val displayManager =
                getSystemService(Context.DISPLAY_SERVICE) as DisplayManager
            val densityDpi = resources.displayMetrics.densityDpi

            val vd = displayManager.createVirtualDisplay(
                "CosmicObserverWallpaperDisplay",
                width,
                height,
                densityDpi,
                surface,
                DisplayManager.VIRTUAL_DISPLAY_FLAG_OWN_CONTENT_ONLY,
                null,
                null
            )
            virtualDisplay = vd

            val assetLoader = WebViewAssetLoader.Builder()
                .setDomain("appassets.androidplatform.net")
                .addPathHandler(
                    "/",
                    WebViewAssetLoader.AssetsPathHandler(this@CosmicWallpaperService)
                )
                .build()

            currentIsDarkMode = isSystemDarkMode()

            val wv = WebView(this@CosmicWallpaperService).apply {
                setBackgroundColor(if (currentIsDarkMode) Color.BLACK else LIGHT_BACKGROUND_COLOR)
                setLayerType(View.LAYER_TYPE_HARDWARE, null)
                overScrollMode = View.OVER_SCROLL_NEVER
                isHorizontalScrollBarEnabled = false
                isVerticalScrollBarEnabled = false

                settings.apply {
                    javaScriptEnabled = true
                    domStorageEnabled = true
                    allowFileAccess = false
                    allowContentAccess = false
                    mixedContentMode = WebSettings.MIXED_CONTENT_NEVER_ALLOW
                    useWideViewPort = true
                    loadWithOverviewMode = true
                }

                val engineBridge = CosmicAndroidBridge(
                    context = this@CosmicWallpaperService,
                    onEngineReady = {
                        isEngineReady = true
                        currentIsDarkMode = isSystemDarkMode()
                        syncThemeToWeb(currentIsDarkMode)
                        if (currentVisible) {
                            gyroController?.start()
                        }
                        syncVisibilityToWeb(currentVisible)
                    }
                )
                bridge = engineBridge

                addJavascriptInterface(engineBridge, "CosmicAndroidBridge")

                webViewClient = object : WebViewClient() {
                    override fun shouldInterceptRequest(
                        view: WebView,
                        request: WebResourceRequest
                    ): WebResourceResponse? {
                        return assetLoader.shouldInterceptRequest(request.url)
                    }
                }

                loadUrl("https://appassets.androidplatform.net/index.html?androidWallpaper=1")
            }

            webView = wv

            val pres = object : Presentation(this@CosmicWallpaperService, vd.display) {}
            pres.setContentView(
                wv,
                ViewGroup.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT,
                    ViewGroup.LayoutParams.MATCH_PARENT
                )
            )
            pres.show()
            presentation = pres
        }

        override fun onVisibilityChanged(visible: Boolean) {
            super.onVisibilityChanged(visible)
            currentVisible = visible
            mainHandler.post {
                if (visible) {
                    val latestDark = isSystemDarkMode()
                    if (latestDark != currentIsDarkMode) {
                        currentIsDarkMode = latestDark
                        webView?.setBackgroundColor(
                            if (latestDark) Color.BLACK else LIGHT_BACKGROUND_COLOR
                        )
                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O_MR1) {
                            notifyColorsChanged()
                        }
                    }
                    webView?.onResume()
                    gyroController?.start()
                    syncThemeToWeb(currentIsDarkMode)
                } else {
                    gyroController?.stop()
                    webView?.onPause()
                }
                syncVisibilityToWeb(visible)
            }
        }

        override fun onOffsetsChanged(
            xOffset: Float,
            yOffset: Float,
            xOffsetStep: Float,
            yOffsetStep: Float,
            xPixelOffset: Int,
            yPixelOffset: Int
        ) {
            super.onOffsetsChanged(
                xOffset,
                yOffset,
                xOffsetStep,
                yOffsetStep,
                xPixelOffset,
                yPixelOffset
            )
            if (!isEngineReady || !currentVisible) return
            mainHandler.post {
                val js = String.format(
                    Locale.US,
                    "window.__COSMIC_ANDROID_OFFSETS__?.(%.4f, %.4f);",
                    xOffset,
                    yOffset
                )
                webView?.evaluateJavascript(js, null)
            }
        }

        override fun onTouchEvent(event: MotionEvent) {
            super.onTouchEvent(event)
            if (!currentVisible) return

            val actionName = when (event.actionMasked) {
                MotionEvent.ACTION_DOWN -> "down"
                MotionEvent.ACTION_MOVE -> "move"
                MotionEvent.ACTION_UP -> "up"
                MotionEvent.ACTION_CANCEL -> "cancel"
                else -> null
            }

            val density = resources.displayMetrics.density.coerceAtLeast(1f)
            val cssX = event.x / density
            val cssY = event.y / density

            val copy = MotionEvent.obtain(event)
            mainHandler.post {
                webView?.dispatchTouchEvent(copy)
                copy.recycle()

                if (actionName != null && isEngineReady) {
                    val js = String.format(
                        Locale.US,
                        "window.__COSMIC_ANDROID_TOUCH__?.('%s', %.2f, %.2f);",
                        actionName,
                        cssX,
                        cssY
                    )
                    webView?.evaluateJavascript(js, null)
                }
            }
        }

        override fun onSurfaceDestroyed(holder: SurfaceHolder) {
            super.onSurfaceDestroyed(holder)
            mainHandler.post {
                gyroController?.stop()
                cleanupPresentation()
            }
        }

        override fun onDestroy() {
            activeEngines.remove(this)
            mainHandler.post {
                gyroController?.stop()
                gyroController = null
                cleanupPresentation()
            }
            super.onDestroy()
        }

        private fun syncThemeToWeb(isDark: Boolean) {
            if (!isEngineReady) return
            webView?.evaluateJavascript(
                "window.__COSMIC_ANDROID_THEME__?.($isDark);",
                null
            )
        }

        private fun syncVisibilityToWeb(visible: Boolean) {
            if (!isEngineReady) return
            webView?.evaluateJavascript(
                "window.__COSMIC_ANDROID_LIFECYCLE__?.($visible, $isPreview);",
                null
            )
        }

        private fun cleanupPresentation() {
            isEngineReady = false
            bridge?.release()
            bridge = null
            presentation?.dismiss()
            presentation = null
            webView?.apply {
                stopLoading()
                destroy()
            }
            webView = null
            virtualDisplay?.release()
            virtualDisplay = null
        }
    }
}
