# Cosmic Observer — Android Live Wallpaper APK Build & Install Guide

This package contains the complete, lightweight Kotlin + Gradle Android Live Wallpaper project (`android/`) pre-loaded with the offline 3D WebGL assets (`android/app/src/main/assets/`) and an automated GitHub Actions cloud APK builder (`.github/workflows/build-android-apk.yml`).

## What Is Included

- **Native Android `WallpaperService` (`CosmicWallpaperService`)**: Runs the 3D Cosmic Observer character, continuous planetary solar system orbits, gyroscope head movement, touch-to-look head tracking, and minimal live clock directly on your Android home screen.
- **Native Android `SensorManager` (`CosmicGyroController`)**: Smoothly drives head movement when you tilt your phone, automatically returns the head to its normal forward gaze when still, and unregisters immediately when the wallpaper is not visible to save battery.
- **Simple Companion App (`LauncherActivity`)**: Shows a live interactive preview with a single **Set as Wallpaper** button that opens Android's system Live Wallpaper preview and confirmation screen.

---

## Option 1: Build Installable APK in the Cloud (GitHub Actions — No Android Studio Needed)

1. Unzip `cosmic-observer-android-apk-kit.zip` and push both `android/` and `.github/` to a GitHub repository (`main` branch).
2. Open your repository on GitHub → click the **Actions** tab → select **Build Cosmic Observer Android APK** (runs automatically on push, or click **Run workflow**).
3. Wait ~2–3 minutes for the workflow to finish, then download the **CosmicObserver-APK** artifact under **Artifacts**.
4. Unzip `CosmicObserver-APK.zip` on your Android phone and tap `CosmicObserver-debug.apk` to install.

## Option 2: Build Installable APK Locally in Android Studio

1. Open the `android/` folder in **Android Studio (Ladybug / 2024.2+)** with Android SDK 35 & JDK 17.
2. Wait for Gradle sync to complete, then select **Build > Build Bundle(s) / APK(s) > Build APK(s)** (or run `./gradlew assembleDebug` inside `android/`).
3. Transfer `android/app/build/outputs/apk/debug/app-debug.apk` to your Android phone and tap it to install.

---

## How to Set the Live Wallpaper on Your Android Phone

1. Install the APK on your Android phone (allow "Install unknown apps" if prompted by your browser or file manager).
2. Open **Cosmic Observer** from your app drawer.
3. Preview the character, planetary motion, touch response, and live clock.
4. Tap **Set as Wallpaper**.
5. Android's Live Wallpaper preview screen opens — tap **Set wallpaper** (choose **Home screen** or **Home and lock screens**).
6. You can close the app — Cosmic Observer now runs directly on your home screen.
